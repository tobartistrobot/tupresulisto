# Marketing Skills Versions

Current versions of all skills. Agents can compare against local versions to check for updates.

| Skill | Version | Last Updated |
|-------|---------|--------------|
| ab-test-setup | 1.0.0 | 2026-01-27 |
| analytics-tracking | 1.0.0 | 2026-01-27 |
| competitor-alternatives | 1.0.0 | 2026-01-27 |
| content-strategy | 1.0.0 | 2026-01-27 |
| copy-editing | 1.0.0 | 2026-01-27 |
| copywriting | 1.0.0 | 2026-01-27 |
| email-sequence | 1.0.0 | 2026-01-27 |
| form-cro | 1.0.0 | 2026-01-27 |
| free-tool-strategy | 1.0.0 | 2026-01-27 |
| launch-strategy | 1.0.0 | 2026-01-27 |
| marketing-ideas | 1.0.0 | 2026-01-27 |
| marketing-psychology | 1.0.0 | 2026-01-27 |
| onboarding-cro | 1.0.0 | 2026-01-27 |
| page-cro | 1.0.0 | 2026-01-27 |
| paid-ads | 1.0.0 | 2026-01-27 |
| paywall-upgrade-cro | 1.0.0 | 2026-01-27 |
| popup-cro | 1.0.0 | 2026-01-27 |
| pricing-strategy | 1.0.0 | 2026-01-27 |
| product-marketing-context | 1.0.0 | 2026-01-27 |
| programmatic-seo | 1.0.0 | 2026-01-27 |
| referral-program | 1.0.0 | 2026-01-27 |
| schema-markup | 1.0.0 | 2026-01-27 |
| seo-audit | 1.0.0 | 2026-01-27 |
| signup-flow-cro | 1.0.0 | 2026-01-27 |
| social-content | 1.0.0 | 2026-01-27 |

## Recent Changes

### 2026-01-27
- Initial version tracking added
- Added tools registry with 29 integration guides

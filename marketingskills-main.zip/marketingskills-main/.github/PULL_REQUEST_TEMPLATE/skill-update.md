## Skill Update

**Skill:** `skills/SKILL-NAME`

## Summary

<!-- What changes are you making and why? -->

## Type of update

- [ ] Bug fix
- [ ] Improved instructions
- [ ] Added references/scripts
- [ ] Other

## Checklist

- [ ] Changes are focused and minimal
- [ ] `SKILL.md` is still under 500 lines
- [ ] No sensitive data or credentials
- [ ] Tested locally with AI agent

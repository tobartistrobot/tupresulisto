## New Skill

**Skill name:** `skills/SKILL-NAME`

## Summary

<!-- What does this skill do and when should it be used? -->

## Checklist

- [ ] `name` matches directory name exactly
- [ ] `name` follows naming rules (lowercase, hyphens, no `--`)
- [ ] `description` is 1-1024 chars with trigger phrases
- [ ] `SKILL.md` is under 500 lines
- [ ] No sensitive data or credentials
- [ ] Tested locally with AI agent
